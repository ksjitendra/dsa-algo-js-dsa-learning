
let data = []
let currentSize = data.length 

let str = "teststr"

let strArray = 



